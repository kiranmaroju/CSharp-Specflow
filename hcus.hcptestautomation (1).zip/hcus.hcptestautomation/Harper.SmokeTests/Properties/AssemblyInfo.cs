﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Harper.SmokeTests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Harper")]
[assembly: AssemblyProduct("Harper.SmokeTests")]
[assembly: AssemblyCopyright("Copyright © EPAM Systems 2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: ComVisible(false)]

[assembly: Guid("ccfec1a2-4a70-4dbe-a346-5f1e7aed719e")]
