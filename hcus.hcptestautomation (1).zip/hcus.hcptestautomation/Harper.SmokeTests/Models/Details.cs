﻿namespace Harper.SmokeTests.Models
{
    public class Details
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string CompanyName { get; set; }
        public string JobTitle { get; set; }
        public string ShowName { get; set; }
        public string CompanyWebsite { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Office { get; set; }
        public string AddressType { get; set; }
        public string ReasonReturned { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Facebook { get; set; }
        public string Instagram { get; set; }
        public string Twitter { get; set; }
        public string LinkedIn { get; set; }
        public string Youtube { get; set; }
        public string ContactProfile { get; set; }
        public string Comment { get; set; }
        public string FirstNameUpdated { get; set; }
        public string LastNameUpdated { get; set; }
        public string CompanyNameUpdated { get; set; }
        public string MobileUpdated { get; set; }
        public string GroupName { get; set; }
        public string BookingType { get; set; }
        public string BookingFormat { get; set; }
        public string GroupNotes { get; set; }
        public string Company { get; set; }
        public string ContactName { get; set; }
        public string Market { get; set; }
        public string EventDescription { get; set; }
        public string EventURL { get; set; }
        public string EventAddress { get; set; }
        public string EventState { get; set; }
        public string EventCity { get; set; }
        public string EventZip { get; set; }
        public string PreEvent { get; set; }
        public string PostEvent { get; set; }
        public string CompanyUpdated { get; set; }
        public string ListName { get; set; }
        public string ListNotes { get; set; }
        public string ListNameUpdated { get; set; }
        public string CopySearchCriteria { get; set; }

        public string PartialCompanyName { get; set; }

        public string ISBN { get; set; }

        public string TilesISBN { get; set; }

    }
}
