﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using Harper.SmokeTests.Models;
using System;
using static System.String;
using static HARP.AutomationFramework.Utilities.WaitHelper;

namespace Harper.SmokeTests.PageObjects
{
    public class EventPage : BasePage
    {
        [NewLocator("//a[text()='Schedule']", Locators.Xpath)]
        public Button ScheduleLinkButton;

        [NewLocator("//a[contains(text(),'Add to schedule')]", Locators.Xpath)]
        public Button AddToScheduleButton;

        [NewLocator("//app-select[@placeholder='Booking Type']//div//div//select", Locators.Xpath)]
        public DropDown BookingTypeField;

        [NewLocator("//app-select[@placeholder='Booking Format']//div//div//select", Locators.Xpath)]
        public DropDown BookingFormatField;

        [NewLocator("//label[contains(text(),'Company')]/following::input[1]", Locators.Xpath)]
        public TextBox CompanyField;

        [NewLocator("//label[contains(text(),'Contact Name')]/following::input[1]", Locators.Xpath)]
        public TextBox ContactNameField;

        [NewLocator("//app-select[@placeholder='Market']//div//div//select", Locators.Xpath)]
        public DropDown MarketField;

        [NewLocator("//label[text()='Event Description']/following::textarea[1]", Locators.Xpath)]
        public TextBox EventDescriptionField;

        [NewLocator("//label[text()='Event URL']/following::input[1]", Locators.Xpath)]
        public TextBox EventUrlField;

        [NewLocator("//label[text()='Event Address']/following::input[1]", Locators.Xpath)]
        public TextBox EventAddressField;

        [NewLocator("//app-select[@placeholder='State/Province']//div//div//select", Locators.Xpath)]
        public DropDown StateField;

        [NewLocator("//label[contains(text(),'City')]/following::input[1]", Locators.Xpath)]
        public TextBox CityField;

        [NewLocator("//label[contains(text(),'Zip')]/following::input[1]", Locators.Xpath)]
        public TextBox ZipField;

        [NewLocator("//label[contains(text(),'Pre Event Notes')]/following::textarea[1]", Locators.Xpath)]
        public TextBox PreEventField;

        [NewLocator("//label[contains(text(),'Post Event Notes')]/following::textarea[1]", Locators.Xpath)]
        public TextBox PostEventField;

        [NewLocator("//button[contains(text(),'Save')]", Locators.Xpath)]
        public Button SaveEventButton;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button SaveEventOkButton;

        [NewLocator("//button[@ngbtooltip='Delete schedule list']", Locators.Xpath)]
        public Button DeleteEventButton;

        //[NewLocator("//i[@class='fa fa-trash']", Locators.Xpath)]
        //public Button DeleteEventButton;

        [NewLocator("//a[@ngbtooltip='Edit event']", Locators.Xpath)]
        public Button EditEventButton;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button DeleteEventOkButton;

        [NewLocator("//app-results-cell-display[contains(text(),'VNR Prod Solution')]", Locators.Xpath)]
        public Button CompanyDisplayed;

        [NewLocator("//app-results-cell-display[contains(text(),'VNR Prod Solution Edit')]", Locators.Xpath)]
        public Button CompanyEditedDisplayed;

        [NewLocator("//span[contains(text(),'Reports')]", Locators.Xpath)]
        public Button ReportButton;

        [NewLocator("//a[contains(text(),'Publicity Recap Report')]", Locators.Xpath)]
        public Button PublicityCapReportButton;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button ReportDownloadOkButton;

        public override bool IsOpened => CompanyDisplayed.Visible;

        public bool Edited => CompanyEditedDisplayed.Visible;

        public bool DownloadAvailable => PublicityCapReportButton.Enabled;

        public void FillEventFields(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.BookingType)) { WaitElement(BookingTypeField); BookingTypeField.SelectValueByValue(parameters.BookingType); }
            if (!IsNullOrEmpty(parameters.BookingFormat)) { WaitElement(BookingFormatField); BookingFormatField.SelectValueByValue(parameters.BookingFormat); }
            if (!IsNullOrEmpty(parameters.Company)) { WaitElement(CompanyField); CompanyField.CleanField(); CompanyField.SendText(parameters.Company); }
            if (!IsNullOrEmpty(parameters.ContactName)) { WaitElement(ContactNameField); ContactNameField.CleanField(); ContactNameField.SendText(parameters.ContactName); }
            if (!IsNullOrEmpty(parameters.Market)) { WaitElement(MarketField); MarketField.SelectValueByText(parameters.Market); }
            if (!IsNullOrEmpty(parameters.EventDescription)) { WaitElement(EventDescriptionField); EventDescriptionField.CleanField(); EventDescriptionField.SendText(parameters.EventDescription); }
            if (!IsNullOrEmpty(parameters.EventURL)) { WaitElement(EventUrlField); EventUrlField.CleanField(); EventUrlField.SendText(parameters.EventURL); }
            if (!IsNullOrEmpty(parameters.EventAddress)) { WaitElement(EventAddressField); EventAddressField.CleanField(); EventAddressField.SendText(parameters.EventAddress); }
            if (!IsNullOrEmpty(parameters.EventCity)) { WaitElement(CityField); CityField.SendText(parameters.EventCity); }
            if (!IsNullOrEmpty(parameters.EventState)) { WaitElement(StateField); StateField.SelectValueByText(parameters.EventState); }
            if (!IsNullOrEmpty(parameters.EventZip)) { WaitElement(ZipField); ZipField.SendText(parameters.EventZip); }
            if (!IsNullOrEmpty(parameters.PreEvent)) { WaitElement(PreEventField); PreEventField.SendText(parameters.PreEvent); }
            if (!IsNullOrEmpty(parameters.PostEvent)) { WaitElement(PostEventField); PostEventField.SendText(parameters.PostEvent); }
            SaveEventButton.Click();
            SaveEventOkButton.Click();
        }

        public void EditEvent(Details parameters)
        {
            EditEventButton.Click();
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.CompanyUpdated)) { WaitElement(CompanyField); CompanyField.CleanField(); CompanyField.SendText(parameters.CompanyUpdated); }
            SaveEventButton.Click();
            SaveEventOkButton.Click();
        }
    }
}
