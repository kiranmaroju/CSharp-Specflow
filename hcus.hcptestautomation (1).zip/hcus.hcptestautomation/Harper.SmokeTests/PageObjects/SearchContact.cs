﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using NUnit.Framework;
using System;
using static System.String;
using static HARP.AutomationFramework.Utilities.WaitHelper;
using Harper.SmokeTests.Models;

namespace Harper.SmokeTests.PageObjects
{
    public class SearchContact : BasePage
    {
        [NewLocator("//button[@ngbtooltip='Delete contact']", Locators.Xpath)]
        public Button DeleteContactButton;

        [NewLocator("//a[@ngbtooltip='Edit contact']", Locators.Xpath)]
        public Button EditContactButton;

        [NewLocator("//label[text()='Value']/following::input[1]", Locators.Xpath)]
        public TextBox SearchContactBar;

        [NewLocator("//button[@type='submit'][contains(text(),'Search')]", Locators.Xpath)]
        public Button ContactSearchButton;

        [NewLocator("//tr[starts-with(@class,'active-item') or starts-with(@class,'ng-star-inserted')]", Locators.Xpath)]
        public Label SearchContactResult;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button DeleteContactOkButton;

        [NewLocator("//app-select[@placeholder='Field']//div//div//select", Locators.Xpath)]
        public DropDown ContactSelectFeild;

        [NewLocator("//*[text()=' Search for mailings ']/button[1]", Locators.Xpath)]
        public Button SearchExpandCollaspe;

        [NewLocator("//input[@placeholder='mm/dd/yyyy']", Locators.Xpath)]
        public TextBox DateSearch;

        public override bool IsOpened => SearchContactResult.Visible;

        public void EnterSearchCriteria(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.Email)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.Email); }
        }

        public void EnterSearchCriteriaEdited(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.MobileUpdated)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.MobileUpdated); }
        }

        public void EnterSearchCriteriaByName(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.FirstName); }
        }

        public void EnterSearchCriteriaByPartialCompanyName(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.PartialCompanyName)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.PartialCompanyName); }
        }

        public void EnterSearchCriteriaByCompanyName(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.CompanyName); }
        }

        public void EnterSearchCriteriaByShowName(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.ShowName)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.ShowName); }
        }

        public void EnterSearchCriteriaByJobTitle(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.JobTitle)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.JobTitle); }
        }

        public void EnterSearchCriteriaByMobile(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.Mobile)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.Mobile); }
        }

        public void EnterSearchCriteriaByOffice(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.Office)) { WaitElement(SearchContactBar).CleanField(); SearchContactBar.SendText(parameters.Office); }
        }
    }
}
