﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using Harper.SmokeTests.Models;
using OpenQA.Selenium;
using static System.String;
using static HARP.AutomationFramework.Utilities.WaitHelper;
using static HARP.AutomationFramework.WebElementWrappers.CommonHelpers.WebElementExtension;
using System;
using HARP.AutomationFramework.Utilities;

namespace Harper.SmokeTests.PageObjects
{
    public class ContactPage : BasePage
    {
        [NewLocator("//label[contains(text(),'First Name')]/following::input[1]", Locators.Xpath)]
        public TextBox FirstNameField;

        [NewLocator("//label[contains(text(),'Last Name')]/following::input[1]", Locators.Xpath)]
        public TextBox LastNameField;

        [NewLocator("//label[contains(text(),'Company Name')]/following::input[1]", Locators.Xpath)]
        public TextBox CompanyNameField;

        [NewLocator("//label[contains(text(),'Middle Name')]/following::input[1]", Locators.Xpath)]
        public TextBox MiddleNameField;

        [NewLocator("//label[contains(text(),'Job Title')]/following::input[1]", Locators.Xpath)]
        public TextBox JobTitleField;

        [NewLocator("//label[contains(text(),'Show Name')]/following::input[1]", Locators.Xpath)]
        public TextBox ShowNameField;

        [NewLocator("//label[contains(text(),'Categories')]/following::input[1]", Locators.Xpath)]
        public TextBox CategoriesField;

        [NewLocator("//label[contains(text(),'Markets')]/following::input[1]", Locators.Xpath)]
        public TextBox MarketsField;

        [NewLocator("//label[contains(text(),'Media Type')]/following::input[1]", Locators.Xpath)]
        public TextBox MediaTypeField;

        [NewLocator("//label[contains(text(),'Company Website')]/following::input[1]", Locators.Xpath)]
        public TextBox CompanyWebsiteField;

        [NewLocator("//label[contains(text(),'Language')]/following::input[1]", Locators.Xpath)]
        public TextBox LanguageField;

        [NewLocator("//label[contains(text(),'Email')]/following::input[1]", Locators.Xpath)]
        public TextBox EmailField;

        [NewLocator("//label[contains(text(),'Office')]/following::input[1]", Locators.Xpath)]
        public TextBox OfficeField;

        [NewLocator("//label[contains(text(),'Mobile')]/following::input[1]", Locators.Xpath)]
        public TextBox MobileField;

        [NewLocator("//input[@value='+ Add Address']", Locators.Xpath)]
        public Button AddAddressButton;

        [NewLocator("//select[@class='form-control ng-untouched ng-star-inserted ng-dirty ng-invalid']", Locators.Xpath)]
        public DropDown AddressTypeField;

        [NewLocator("//app-select[@placeholder='Reason for Returned Package']//div//div//select", Locators.Xpath)]
        public DropDown ReasonReturnField;

        [NewLocator("//label[contains(text(),'Address 1')]/following::input[1]", Locators.Xpath)]
        public TextBox Address1Field;

        [NewLocator("//label[contains(text(),'Address 2 (Suit')]/following::input[1]", Locators.Xpath)]
        public TextBox Address2Field;

        [NewLocator("//label[contains(text(),'City')]/following::input[1]", Locators.Xpath)]
        public TextBox CityField;

        [NewLocator("//select[@class='form-control placeholder ng-untouched ng-star-inserted ng-dirty ng-invalid']", Locators.Xpath)]
        public DropDown StateField;

        [NewLocator("//label[contains(text(),'Zip')]/following::input[1]", Locators.Xpath)]
        public TextBox ZipField;

        [NewLocator("//input[@type='submit'][@value='Save']", Locators.Xpath)]
        public Button SaveContactButton;

        [NewLocator("//button[text()='Validate']", Locators.Xpath)]
        public Button ValidateButton;

        [NewLocator("//label[contains(text(),'Facebook')]/following::input[1]", Locators.Xpath)]
        public TextBox FacebookField;

        [NewLocator("//label[contains(text(),'Instagram')]/following::input[1]", Locators.Xpath)]
        public TextBox InstagramField;

        [NewLocator("//label[contains(text(),'Twitter')]/following::input[1]", Locators.Xpath)]
        public TextBox TwitterField;

        [NewLocator("//label[contains(text(),'LinkedIn')]/following::input[1]", Locators.Xpath)]
        public TextBox LinkedInField;

        [NewLocator("//label[contains(text(),'YouTube')]/following::input[1]", Locators.Xpath)]
        public TextBox YoutubeField;

        [NewLocator("//textarea[@formcontrolname='pitchingProfile']", Locators.Xpath)]
        public TextBox ContactProfileField;

        [NewLocator("//input[@value='Add Comment']", Locators.Xpath)]
        public Button AddCommentButton;

        [NewLocator("//textarea[@validate-onblur='newComment.control.text']", Locators.Xpath)]
        public TextBox CommentField;

        [NewLocator("//input[@value='Reset']", Locators.Xpath)]
        public Button ResetContact;

        [NewLocator("//a[contains(text(),'Grey, Thomson')]", Locators.Xpath)]
        public Label ContactName;

        [NewLocator("//label[contains(text(),'Name')]/following::input[1]", Locators.Xpath)]
        public TextBox GroupNameField;

        [NewLocator("//label[contains(text(),'Group Notes')]/following::textarea[1]", Locators.Xpath)]
        public TextBox GroupNotesField;

        [NewLocator("//button[contains(text(),'Add contact')]", Locators.Xpath)]
        public Button AddGroupContact;

        [NewLocator("//a[@ngbtooltip='Add To Group']", Locators.Xpath)]
        public Button AddingContact;

        [NewLocator("//span[contains(text(),'×')]", Locators.Xpath)]
        public Button CloseAddPopup;

        [NewLocator("//button[contains(text(),'Save')]", Locators.Xpath)]
        public Button SaveGroup;

        [NewLocator("//button[contains(text(),'Delete group')]", Locators.Xpath)]
        public Button DeleteGroup;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button DeleteGroupOK;

        [NewLocator("//button[contains(text(),'CSV')]", Locators.Xpath)]
        public TextBox UploadButtonCsv;

        [NewLocator("//button[contains(text(),'CISION FILE')]", Locators.Xpath)]
        public TextBox UploadButtonCision;

        [NewLocator("//button[contains(text(),'MUCK RACK')]", Locators.Xpath)]
        public TextBox UploadButtonMuckrack;

        [NewLocator("//button[contains(text(),'Confirm')]", Locators.Xpath)]
        public Button ConfirmUploadButton;

        [NewLocator("//app-checkbox[@class='ng-untouched ng-valid ng-dirty']//span", Locators.Xpath)]
        public Button SelectContact;

        [NewLocator("//button[text()=' Remove contact(s) ']", Locators.Xpath)]
        public Button RemoveContact;

        [NewLocator("//*[@searchtitle='Select Contact(s)']/descendant::button[1]", Locators.Xpath)]
        public Button ExpandCollaspeContact;

        [NewLocator("//input[@value='1']/../span", Locators.Xpath)]
        public RadioButton PublicRadioButton;

        [NewLocator("//input[@value='2']/../span", Locators.Xpath)]
        public RadioButton ListSpecificRadioButton;

        [NewLocator("//*[contains(text(),'View Contact')]", Locators.Xpath)]
        public Label ViewContact;

        [NewLocator("//a[contains(text(),' Duplicated record')]", Locators.Xpath)]
        public Button DuplicateRecordMessage;

        [NewLocator("//*[contains(text(),' Overwrite')]", Locators.Xpath)]
        public Button OverwriteDuplicate;

        [NewLocator("//*[contains(text(),'Total number of contacts:')]/following::span[1]", Locators.Xpath)]
        public Button ContactCount;

        [NewLocator("//span[contains(text(),'Necromancers')]", Locators.Xpath)]
        public Button SelectGroup;

        [NewLocator("//*[text()=' Search for contacts ']/button[1]", Locators.Xpath)]
        public Button SearchExpandCollaspeContact;

        public bool AddingContactDisplayed => AddingContact.Visible;

        public bool UploadDuplicateMessageDisplayed => DuplicateRecordMessage.Visible;

        public string Count => ContactCount.GetAttributeValue("innerHTML");

        public string ReturnCount()
        {
            return Count;
        }


        public void FillAllRequiredFields(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            /*if (!IsNullOrEmpty(parameters.Mobile)) { WaitElement(MobileField); MobileField.CleanField(); MobileField.SendText(parameters.Mobile); }*/
            if (!IsNullOrEmpty(parameters.Email)) { WaitElement(EmailField); EmailField.CleanField(); EmailField.SendText(parameters.Email); }
        }

        public void FillAllFields(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            if (!IsNullOrEmpty(parameters.MiddleName)) { WaitElement(MiddleNameField); MiddleNameField.CleanField(); MiddleNameField.SendText(parameters.MiddleName); }
            if (!IsNullOrEmpty(parameters.JobTitle)) { WaitElement(JobTitleField); JobTitleField.CleanField(); JobTitleField.SendText(parameters.JobTitle); }
            if (!IsNullOrEmpty(parameters.ShowName)) { WaitElement(ShowNameField); ShowNameField.CleanField(); ShowNameField.SendText(parameters.ShowName); }
            CategoriesField.Click();
            CategoriesField.SendText(Keys.Enter);
            MarketsField.Click();
            MarketsField.SendText(Keys.Enter);
            MediaTypeField.Click();
            MediaTypeField.SendText(Keys.Enter);
            if (!IsNullOrEmpty(parameters.CompanyWebsite)) { WaitElement(CompanyWebsiteField); CompanyWebsiteField.CleanField(); CompanyWebsiteField.SendText(parameters.CompanyWebsite); }
            if (!IsNullOrEmpty(parameters.Email)) { WaitElement(EmailField); EmailField.CleanField(); EmailField.SendText(parameters.Email); }
            if (!IsNullOrEmpty(parameters.Mobile)) { WaitElement(MobileField); MobileField.CleanField(); MobileField.SendText(parameters.Mobile); }
            if (!IsNullOrEmpty(parameters.Office)) { WaitElement(OfficeField); OfficeField.CleanField(); OfficeField.SendText(parameters.Office); }
            AddAddressButton.Click();
            if (!IsNullOrEmpty(parameters.AddressType)) { WaitElement(AddressTypeField); AddressTypeField.SelectValueByText(parameters.AddressType); }
            //if (!IsNullOrEmpty(parameters.ReasonReturned)) { WaitElement(ReasonReturnField); ReasonReturnField.Click();WaitElement(ReasonReturnField).SelectValueByValue(parameters.ReasonReturned); }
            if (!IsNullOrEmpty(parameters.Address1)) { WaitElement(Address1Field); Address1Field.SendText(parameters.Address1); }
            if (!IsNullOrEmpty(parameters.Address2)) { WaitElement(Address2Field); Address2Field.SendText(parameters.Address2); }
            if (!IsNullOrEmpty(parameters.City)) { WaitElement(CityField); CityField.SendText(parameters.City); }
            if (!IsNullOrEmpty(parameters.State)) { WaitElement(StateField); StateField.SelectValueByText(parameters.State); }
            if (!IsNullOrEmpty(parameters.Zip)) { WaitElement(ZipField); ZipField.SendText(parameters.Zip); }
            ValidateButton.Click();
            if (!IsNullOrEmpty(parameters.Facebook)) { WaitElement(FacebookField); FacebookField.CleanField(); FacebookField.SendText(parameters.Facebook); }
            if (!IsNullOrEmpty(parameters.Instagram)) { WaitElement(InstagramField); InstagramField.CleanField(); InstagramField.SendText(parameters.Instagram); }
            if (!IsNullOrEmpty(parameters.Twitter)) { WaitElement(TwitterField); TwitterField.CleanField(); TwitterField.SendText(parameters.Twitter); }
            if (!IsNullOrEmpty(parameters.LinkedIn)) { WaitElement(LinkedInField); LinkedInField.CleanField(); LinkedInField.SendText(parameters.LinkedIn); }
            if (!IsNullOrEmpty(parameters.Youtube)) { WaitElement(YoutubeField); YoutubeField.CleanField(); YoutubeField.SendText(parameters.Youtube); }
            if (!IsNullOrEmpty(parameters.ContactProfile)) { WaitElement(ContactProfileField); ContactProfileField.CleanField(); ContactProfileField.SendText(parameters.ContactProfile); }
            AddCommentButton.Click();
            if (!IsNullOrEmpty(parameters.Comment)) { WaitElement(CommentField); CommentField.SendText(parameters.Comment); }
        }

        public void EditAllRequiredFields(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.FirstNameUpdated)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstNameUpdated); }
            if (!IsNullOrEmpty(parameters.LastNameUpdated)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastNameUpdated); }
            if (!IsNullOrEmpty(parameters.CompanyNameUpdated)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyNameUpdated); }
            if (!IsNullOrEmpty(parameters.MobileUpdated)) { WaitElement(MobileField); MobileField.CleanField(); MobileField.SendText(parameters.MobileUpdated); }
        }

        public void FillGroupFields(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.GroupName)) { WaitElement(GroupNameField); GroupNameField.SendText(parameters.GroupName); }
            if (!IsNullOrEmpty(parameters.GroupNotes)) { WaitElement(GroupNotesField); GroupNotesField.SendText(parameters.GroupNotes); }
        }

        public void PublicContactWithEmail(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            WaitElement(PublicRadioButton); PublicRadioButton.Click();
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.MiddleName)) { WaitElement(MiddleNameField); MiddleNameField.CleanField(); MiddleNameField.SendText(parameters.MiddleName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            if (!IsNullOrEmpty(parameters.Email)) { WaitElement(EmailField); EmailField.CleanField(); EmailField.SendText(parameters.Email); }
            WaitElement(SaveContactButton); SaveContactButton.Click();

        }

        public void ListSpecificContactWithEmail(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            WaitElement(ListSpecificRadioButton); ListSpecificRadioButton.Click();
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.MiddleName)) { WaitElement(MiddleNameField); MiddleNameField.CleanField(); MiddleNameField.SendText(parameters.MiddleName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            if (!IsNullOrEmpty(parameters.Email)) { WaitElement(EmailField); EmailField.CleanField(); EmailField.SendText(parameters.Email); }
            WaitElement(SaveContactButton); SaveContactButton.Click();

        }

        public void FillRequiredFieldsOffice(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.MiddleName)) { WaitElement(MiddleNameField); MiddleNameField.CleanField(); MiddleNameField.SendText(parameters.MiddleName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            if (!IsNullOrEmpty(parameters.Office)) { WaitElement(OfficeField); OfficeField.CleanField(); OfficeField.SendText(parameters.Office); }

        }

        public void FillRequiredFieldsMobile(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.MiddleName)) { WaitElement(MiddleNameField); MiddleNameField.CleanField(); MiddleNameField.SendText(parameters.MiddleName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            if (!IsNullOrEmpty(parameters.Mobile)) { WaitElement(MobileField); MobileField.CleanField(); MobileField.SendText(parameters.Mobile); }

        }

        public void FillRequiredFieldsEmail(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.FirstName)) { WaitElement(FirstNameField); FirstNameField.CleanField(); FirstNameField.SendText(parameters.FirstName); }
            if (!IsNullOrEmpty(parameters.MiddleName)) { WaitElement(MiddleNameField); MiddleNameField.CleanField(); MiddleNameField.SendText(parameters.MiddleName); }
            if (!IsNullOrEmpty(parameters.LastName)) { WaitElement(LastNameField); LastNameField.CleanField(); LastNameField.SendText(parameters.LastName); }
            if (!IsNullOrEmpty(parameters.CompanyName)) { WaitElement(CompanyNameField); CompanyNameField.CleanField(); CompanyNameField.SendText(parameters.CompanyName); }
            if (!IsNullOrEmpty(parameters.Email)) { WaitElement(EmailField); EmailField.CleanField(); EmailField.SendText(parameters.Email); }

        }
    }
}
