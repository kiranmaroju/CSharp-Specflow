﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using static System.String;
using static HARP.AutomationFramework.Utilities.WaitHelper;
using Harper.SmokeTests.Models;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using System;

namespace Harper.SmokeTests.PageObjects
{
    public class AppconnectSearchPage : BasePage
    {
        [NewLocator("//input[@name='query']", Locators.Xpath)]
        public TextBox SearchBox;

        [NewLocator("//button[@class='book-search__submit-btn btn']", Locators.Xpath)]
        public Button SearchButton;

        [NewLocator("//app-loader//following::div[contains(text(),'Please wait')]", Locators.Xpath)]
        public Label SearchLoader;

        [NewLocator("//div[@class='w-100 book-search-results__overflow-wrapper']//following::tbody/tr[last()]", Locators.Xpath)]
        public Label SearchResult;

        [NewLocator("//button[contains(text(), 'Close')]", Locators.Xpath)]
        public TextBox SearchResutClose;

        [NewLocator("//button[@ngbtooltip='Pin book']", Locators.Xpath)]
        public TextBox PinnedRecord;

        [NewLocator("//button[@ngbtooltip='Unpin book']", Locators.Xpath)]
        public TextBox UnpinnedRecord;

        [NewLocator("//span[contains(text(),'A Girl and Her') or contains(text(),' A GIRL AND HER P...')]", Locators.Xpath)]
        public Label FeedPinnedTitle;

        [NewLocator("//div[@class='w-100 book-search-results__overflow-wrapper']//following::tbody/tr[last()]/td[3]", Locators.Xpath)]
        public Label ResultPinnedTitle;

        [NewLocator("//b[text()='ISBN: ']/following::a[1]", Locators.Xpath)]
        public Button SelectISBN;

        [NewLocator("//a[@ngbtooltip ='View Book']", Locators.Xpath)]
        public Link ISBN_ViewBook;


        public override bool IsOpened => SearchResult.Visible;

        public bool IsPinned => PinnedRecord.Visible;

        public bool IsUnpinned => UnpinnedRecord.Visible;

        public string GetMyFeedPinnedTitle => FeedPinnedTitle.GetAttributeValue("innerText");

        public void SearchByISBN(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.ISBN)) { WaitElement(SearchBox); SearchBox.CleanField(); SearchBox.SendText(parameters.ISBN); }
        }

    }
}
