﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;

namespace Harper.SmokeTests.PageObjects
{
    public class TravelPage : BasePage
    {
        [NewLocator("//a[@ngbtooltip='View Book']", Locators.Xpath)]
        public Button ISBNSelect;

        [NewLocator("//a[contains(text(),'travel')]", Locators.Xpath)]
        public Button Traveltab;

        [NewLocator("//*[@class='is-sticky']/parent::table//tr[2]//td[6]", Locators.Xpath)]
        public TextBox ConfirmationNumber;

        [NewLocator("//label[text()='Name / Confirmation Number']/following::input[1]", Locators.Xpath)]
        public TextBox ConfirmationNumberSearch;

        [NewLocator("//*[@class='is-sticky']/parent::table//tr[1]//td[2]", Locators.Xpath)]
        public TextBox Date;

        [NewLocator("//label[text()='Date']/following::input[1]", Locators.Xpath)]
        public TextBox DateSearch;

        public bool ConfirmationNoDisplayed => ConfirmationNumber.Visible;

        public bool DateDisplayed => Date.Visible;

    }
}
