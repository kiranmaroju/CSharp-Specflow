﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;

namespace Harper.SmokeTests.PageObjects
{
    public class MenuPage : BasePage
    {
        [NewLocator("//a[contains(text(),'Contacts')]", Locators.Xpath)]
        public Button Contacts;

        [NewLocator("//a[contains(text(),'Contacts')]/following::a[text()=' Mailings ']", Locators.Xpath)]
        public Button Mailings;

        [NewLocator("//a[contains(text(),'Search for Contact')]", Locators.Xpath)]
        public Button SearchForContacts;

        [NewLocator("//a[contains(text(),'Create new contact')]", Locators.Xpath)]
        public Button CreateNewContact;

        [NewLocator("//a[contains(text(),'Create new group')]", Locators.Xpath)]
        public Button CreateNewGroup;

        [NewLocator("//a[contains(text(),'Upload contacts')]", Locators.Xpath)]
        public Button UploadContact;

        [NewLocator("//a[contains(text(),'Search for Mailing')]", Locators.Xpath)]
        public Button SearchForMailing;

    }
}
