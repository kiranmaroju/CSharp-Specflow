﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;

namespace Harper.SmokeTests.PageObjects
{
    public class HomePage : BasePage
    {

        [NewLocator("//h2[text() = 'MY FEED']", Locators.Xpath)]
        public Label HomePageFeed;

        [NewLocator("//a[@class='header__logo-link']", Locators.Xpath)]
        public Label Logo;

        public override bool IsOpened => Logo.Visible;

    }
}
