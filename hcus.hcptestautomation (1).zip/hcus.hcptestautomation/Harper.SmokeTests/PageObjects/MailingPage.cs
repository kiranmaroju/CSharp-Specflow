﻿using HARP.AutomationFramework.Attributes;
using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.WebElementWrappers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using System;
using static System.String;
using static HARP.AutomationFramework.Utilities.WaitHelper;
using Harper.SmokeTests.Models;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;

namespace Harper.SmokeTests.PageObjects
{
    public class MailingPage : BasePage
    {
        [NewLocator("//a[text()='Mailings']", Locators.Xpath)]
        public Button MailingLinkButton;

        [NewLocator("//a[contains(text(),'mailing list')]", Locators.Xpath)]
        public Button MailingButton;

        [NewLocator("//button[contains(text(),'Create New List')]", Locators.Xpath)]
        public Button CreateNewListButton;

        [NewLocator("//label[contains(text(),'List Name')]/following::input[1]", Locators.Xpath)]
        public TextBox ListNameField;

        [NewLocator("//label[contains(text(),'List Notes')]/following::textarea[1]", Locators.Xpath)]
        public TextBox ListNotesField;

        [NewLocator("//button[contains(text(),'Save')]", Locators.Xpath)]
        public Button SaveListButton;

        [NewLocator("//span[contains(text(),'Add to list')]", Locators.Xpath)]
        public Button AddToListButton;

        [NewLocator("//a[contains(text(),'Search for contact')]", Locators.Xpath)]
        public Button ListSearchContactButton;

        [NewLocator("//a[contains(text(),'Create New Contact')]", Locators.Xpath)]
        public Button ListCreateContactButton;

        [NewLocator("//label[text()='Value']/following::input[1]", Locators.Xpath)]
        public TextBox SearchMailingListBar;

        [NewLocator("//a[contains(text(),'Upload Contact')]", Locators.Xpath)]
        public Button ListUploadContactButton;

        [NewLocator("//th[text()=' Name ']/preceding::app-checkbox[1]", Locators.Xpath)]
        public Button ContactAddingListSelectButton;

        [NewLocator("//button[contains(text(),'contact(s) to the mailing')]", Locators.Xpath)]
        public Button AddContactListButton;

        [NewLocator("//button[@ngbtooltip='Delete mailing list']", Locators.Xpath)]
        public Button DeleteListButton;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button DeleteListOkButton;

        [NewLocator("//button[contains(text(),'Export')]", Locators.Xpath)]
        public Button ExportButton;

        [NewLocator("//i[@class='fa fa-paste']", Locators.Xpath)]
        public Button CopyMailingListButton;

        [NewLocator("//label[contains(text(),'New Mailing List')]", Locators.Xpath)]
        public Button NewMailingListButton;

        [NewLocator("//button[contains(text(),'Continue')]", Locators.Xpath)]
        public Button CopyMailingListContinueButton;

        [NewLocator("//span[contains(text(),'Search by Title, ISBN, Author')]/preceding::input[1]", Locators.Xpath)]
        public TextBox CopyMailingSearchBar;

        [NewLocator("//span[contains(text(),'Search by Title, ISBN, Author')]/preceding::button[1]", Locators.Xpath)]
        public Button CopyMailingSearchButton;

        [NewLocator("//button[text()=' Select ']", Locators.Xpath)]
        public Button CopyMailingSelect;

        [NewLocator("//button[contains(@class,'btn btn-hide-form')]", Locators.Xpath)]
        public Button ShowHideSearch;

        [NewLocator("//th[text()='List Specific']/preceding::app-checkbox[1]", Locators.Xpath)]
        public Button SelectContact;

        [NewLocator("//button[text()='Copy & Save']", Locators.Xpath)]
        public Button CopyAndSave;

        [NewLocator("//button[contains(text(),'Ok')]", Locators.Xpath)]
        public Button CopyAndSaveOkButton;

        [NewLocator("//input[@type='number']", Locators.Xpath)]
        public TextBox Quantity;

        [NewLocator("//*[text()=' Send ']", Locators.Xpath)]
        public Button Send;

        [NewLocator("//a[text()=' Warehouse ']", Locators.Xpath)]
        public Button Warehouse;

        [NewLocator("//button[text()=' Continue ']", Locators.Xpath)]
        public Button WarehouseContinue;

        [NewLocator("//textarea[@name='specialInstructions']", Locators.Xpath)]
        public TextBox WarehouseSpecialInstructions;

        [NewLocator("//button[text()=' Save ']", Locators.Xpath)]
        public TextBox SpecialInstructionsSave;

        [NewLocator("//button[text()='Cancel']", Locators.Xpath)]
        public TextBox Cancel;

        [NewLocator("//button[text()='Confirm']", Locators.Xpath)]
        public TextBox Confirm;

        [NewLocator("//button[text()='OK']", Locators.Xpath)]
        public TextBox ConfirmOK;

        [NewLocator("//div[contains(@class,'book-general-data')]/following::button[1]", Locators.Xpath)]
        public Button ExpandCollaspe;

        [NewLocator("//b[contains(text(),'E-book ISBN:')]", Locators.Xpath)]
        public Button EbookISBN;

        [NewLocator("//*[@class='modal-body']//input[@type='checkbox']", Locators.Xpath)]
        public Checkbox SettingsCheck;

        [NewLocator("//div[text()='Categories']/following::input[@type='checkbox'][1]", Locators.Xpath)]
        public Checkbox CategoriesCheckbox;

        [NewLocator("//div[text()='Categories']/following::input[@type='checkbox'][1]/following::span[1]", Locators.Xpath)]
        public Checkbox CategoriesCheckboxCheck;

        [NewLocator("//button[contains(text(),'Settings')]", Locators.Xpath)]
        public Button Settings;

        [NewLocator("//button[text()='Set Default']", Locators.Xpath)]
        public Button SetAsDefault;

        [NewLocator("//button[text()='Save']", Locators.Xpath)]
        public Button Save;

        [NewLocator("//span[contains(text(),'Send')]", Locators.Xpath)]
        public Button MailingSend;

        [NewLocator("//a[contains(text(),'Email Blast')]", Locators.Xpath)]
        public Button MailingEmailBlast;

        [NewLocator("//p[contains(text(),'Subject:')]/following::input[1]", Locators.Xpath)]
        public TextBox MailingEmailSubject;

        [NewLocator("//textarea[contains(@name,'emailBody')]", Locators.Xpath)]
        public TextBox MailingEmailBody;

        [NewLocator("//p[contains(text(),'Subject:')]/following::input[2]", Locators.Xpath)]
        public TextBox FileUpload;

        [NewLocator("//p[contains(text(),'Subject:')]/following::input[2]/following::button", Locators.Xpath)]
        public Button MailingAttach;

        [NewLocator("//button[contains(@class,'send-email__actions')]", Locators.Xpath)]
        public Button MailingSendEmail;

        [NewLocator("//p[@class='book-info author']", Locators.Xpath)]
        public TextBox MailingsAuthor;

        [NewLocator("//p[@class='book-info isbn text-secondary']", Locators.Xpath)]
        public TextBox MailingISBN;

        [NewLocator("//h5[contains(@class,'book-title ')]", Locators.Xpath)]
        public TextBox MailingTitle;

        [NewLocator("//p[contains(@class, 'book-info season')]", Locators.Xpath)]
        public TextBox MailingSeasonMonth;

        [NewLocator("//button[contains(text(),'Add Titles')]", Locators.Xpath)]
        public Button AddTitles;

        [NewLocator("//input[contains(@placeholder,'Search by Title, ISBN, Author')]", Locators.Xpath)]
        public TextBox TitlesSearch;

        [NewLocator("//a[@ngbtooltip='Add To Mailing List']", Locators.Xpath)]
        public Button TitlesAddISBN;

        [NewLocator("//span[contains(text(),'×')]", Locators.Xpath)]
        public Button TitlesClose;

        [NewLocator("//div[@class='all-mailing-results position-relative']/table/tbody/tr/td[1]/app-permission-gate", Locators.Xpath)]
        public Link MailingListName;

        [NewLocator("//a[text()=' mailing list '] ", Locators.Xpath)]
        public Link MailingListTab;

        [NewLocator("//a[text()=' Create New Contact ']", Locators.Xpath)]
        public Link CreateNewContact;

        [NewLocator("//app-manage-columns[@for='mailing']/button[@class='btn']", Locators.Xpath)]
        public Button SettingsButton;

        [NewLocator("//button[@class='btn btn-secondary']", Locators.Xpath)]
        public Button SettingsSetDefaultButton;

        [NewLocator("//a[@ngbtooltip='View Contact.']", Locators.Xpath)]
        public Link Viewcontact;

        public bool ExportEnabled => ExportButton.Enabled;
        public bool EbookISBNDisplayed => EbookISBN.Visible;
        public bool CategoriesState => CategoriesCheckbox.Checked;
        public bool CreateNewListButtonDisplayed => CreateNewListButton.Visible;
        public string Title => MailingTitle.GetAttributeValue("innerHTML");
        public string ISBN => MailingISBN.GetAttributeValue("innerHTML");
        public string AuthorName => MailingsAuthor.GetAttributeValue("innerHTML");
        public string SeasonMonth => MailingSeasonMonth.GetAttributeValue("innerHTML");
        public bool DeleteOption => DeleteListButton.Visible;

        public string GetMailingData(string Title)
        {
            string extractedTitle = Title.Substring(Title.LastIndexOf(":") + 1);
            if (extractedTitle.Contains(">"))
            {
                extractedTitle = Title.Substring(Title.LastIndexOf(">") + 1);
            }
            return extractedTitle.Trim();
        }

        public string ReturnTitle()
        {
            return Title;
        }

        public void EnterSearchCriteria(Details parameters)
        {
            if (!IsNullOrEmpty(parameters.ListName)) { WaitElement(SearchMailingListBar).CleanField(); SearchMailingListBar.SendText(parameters.ListName); }
        }

        public void FillListFields(Details parameters)
        {
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.ListName)) { WaitElement(ListNameField); ListNameField.SendText(parameters.ListName); }
            if (!IsNullOrEmpty(parameters.ListNotes)) { WaitElement(ListNameField); ListNotesField.SendText(parameters.ListNotes); }
            SaveListButton.Click();
        }

        public void CopyNewMailingList(Details parameters)
        {
            CopyMailingListButton.Click();
            WaitFor(new TimeSpan(1));
            if (!IsNullOrEmpty(parameters.CopySearchCriteria)) { WaitElement(CopyMailingSearchBar); CopyMailingSearchBar.SendText(parameters.CopySearchCriteria); }
            CopyMailingSearchButton.Click();
            WaitHelper.WaitFor(10.Seconds());
            CopyMailingSelect.Click();
            if (!IsNullOrEmpty(parameters.ListNameUpdated)) { WaitElement(ListNameField); ListNameField.SendText(parameters.ListNameUpdated); }
            if (!IsNullOrEmpty(parameters.ListNotes)) { WaitElement(ListNameField); ListNotesField.SendText(parameters.ListNotes); }
            CopyMailingListContinueButton.Click();
            WaitHelper.WaitFor(4.Seconds());
            SelectContact.Click();
            CopyAndSave.Click();
            WaitHelper.WaitFor(10.Seconds());
           // CopyAndSaveOkButton.Click();
           // WaitHelper.WaitFor(15.Seconds());
        }
    }
}
