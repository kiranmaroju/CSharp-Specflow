﻿using System;
using TechTalk.SpecFlow;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using Harper.SmokeTests.Models;
using Harper.SmokeTests.Steps;
using NUnit.Framework;
using TechTalk.SpecFlow.Assist;

namespace Harper.SmokeTests.Steps
{
    [Binding]
    public class SearchForContactsSteps : BaseSteps
    {
        [When(@"Save The Contact created")]
        public void WhenSaveTheContactCreated()
        {
            ContactPage.SaveContactButton.Click();
            WaitHelper.WaitFor(10.Seconds());
            ContactPage.WaitUntilLoadSpinnerDisappear();
            Assert.IsTrue(ContactPage.ViewContact.Visible);
            WaitHelper.WaitFor(10.Seconds());
        }

        [When(@"Enter only the Name, Company and Email")]
        public void WhenEnterOnlyTheNameCompanyAndEmail(Table table)
        {
            var Params = table.CreateInstance<Details>();
            ContactPage.FillRequiredFieldsEmail(Params);
            WaitHelper.WaitFor(10.Seconds());
        }

        [When(@"Enter only the Name, Company and Office")]
        public void WhenEnterOnlyTheNameCompanyAndOffice(Table table)
        {
            var Params = table.CreateInstance<Details>();
            ContactPage.FillRequiredFieldsOffice(Params);
            WaitHelper.WaitFor(10.Seconds());
        }

        [When(@"Enter only the Name, Company and Mobile")]
        public void WhenEnterOnlyTheNameCompanyAndMobile(Table table)
        {
            var Params = table.CreateInstance<Details>();
            ContactPage.FillRequiredFieldsMobile(Params);
            WaitHelper.WaitFor(10.Seconds());
        }

        [When(@"Search the contact by Name")]
        public void WhenSearchTheContactByName(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Name");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Company")]
        public void WhenSearchTheContactByCompany(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Company");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Email")]
        public void WhenSearchTheContactByEmail(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Email");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Office")]
        public void WhenSearchTheContactByOffice(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Office");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Media Type")]
        public void WhenSearchTheContactByMediaType(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("mediaTypes");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Markets")]
        public void WhenSearchTheContactByMarkets(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("markets");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Show Name")]
        public void WhenSearchTheContactByShowName(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("ShowName");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Job Title")]
        public void WhenSearchTheContactByJobTitle(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("JobTitle");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Languages")]
        public void WhenSearchTheContactByLanguages(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("languages");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Categories")]
        public void WhenSearchTheContactByCategories(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("topics");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Group Name")]
        public void WhenSearchTheContactByGroupName(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("GroupName");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by National USA")]
        public void WhenSearchTheContactByNationalUSA(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("NationalUSA");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Created By")]
        public void WhenSearchTheContactByCreatedBy(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("CreatedBy");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Search the contact by Updated By")]
        public void WhenSearchTheContactByUpdatedBy(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("UpdatedBy");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }
    }
}
