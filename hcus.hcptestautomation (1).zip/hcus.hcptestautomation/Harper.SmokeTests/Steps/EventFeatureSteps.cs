﻿using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using Harper.SmokeTests.Models;
using Harper.SmokeTests.Steps;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Harper.SmokeTests
{
    [Binding]
    public class EventFeatureSteps : BaseSteps
    {
        [When(@"I am on Schedule Event page")]
        public void WhenIAmOnScheduleEventPage()
        {
            EventPage.ScheduleLinkButton.Click();
            WaitHelper.WaitFor(3.Seconds());
            EventPage.AddToScheduleButton.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"Create an Event")]
        public void WhenCreateAnEvent(Table table)
        {
            var Params = table.CreateInstance<Details>();
            EventPage.FillEventFields(Params);
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Edit Event Created")]
        public void WhenEditEventCreated(Table table)
        {
            var Params = table.CreateInstance<Details>();
            EventPage.EditEvent(Params);
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Delete the Event")]
        public void WhenDeleteTheEvent()
        {
            EventPage.DeleteEventButton.Click();
            EventPage.DeleteEventOkButton.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [Then(@"Verify Event is added")]
        public void ThenVerifyEventIsAdded()
        {
            WaitHelper.WaitFor(2.Seconds());
            Assert.IsTrue(EventPage.IsOpened);
            Console.WriteLine("Event Displayed");
        }

        [Then(@"Verify Event is edited")]
        public void ThenVerifyEventIsEdited()
        {
            WaitHelper.WaitFor(2.Seconds());
            Assert.IsTrue(EventPage.Edited);
            Console.WriteLine("Event Edited Displayed");
        }

        [Then(@"Verify event is deleted")]
        public void ThenVerifyEventIsDeleted()
        {
            WaitHelper.WaitFor(2.Seconds());
            Assert.IsFalse(EventPage.Edited);
            Console.WriteLine("Event Deleted Successfully");
        }

        [When(@"Report is exported")]
        public void WhenReportIsExported()
        {
            EventPage.ReportButton.Click();
            WaitHelper.WaitFor(4.Seconds());
            Assert.IsTrue(EventPage.DownloadAvailable);
            EventPage.PublicityCapReportButton.Click();
            EventPage.ReportDownloadOkButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

    }
}
