﻿using HARP.AutomationFramework.Exceptions;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using Harper.SmokeTests.PageObjects;
using Harper.SmokeTests.Steps;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace Harper.SmokeTests
{
    [Binding]
    public class AppconnectSearchSteps : BaseSteps
    {
        [When(@"Perform valid (.*) Isbn search")]
        [When(@"Perform valid (.*)  Author search")]
        [When(@"Perform valid (.*)  Title search")]
        public void WhenPerformValidIsbnSearch(string criteria)
        {
            AppconnectSearchPage.SearchBox.CleanField();
            AppconnectSearchPage.SearchBox.SendText(criteria);
        }

        [When(@"Click on Search Button")]
        public void WhenClickOnSearchButton()
        {
            AppconnectSearchPage.SearchButton.Click();
            AppconnectSearchPage.WaitUntilLoadSpinnerDisappear();
        }

        [Then(@"Search Result should be Displayed")]
        public void ThenSearchResultShouldBeDisplayed()
        {
            if (!WaitHelper.WaitUntil(() => AppconnectSearchPage.IsOpened))
                throw new AutomationException("Search Result is not displayed");
        }

        [Then(@"Pin the searched Record")]
        public void ThenPinTheSearchedRecord()
        {
            WaitHelper.WaitFor(10.Seconds());
            AppconnectSearchPage.PinnedRecord.Click();
            WaitHelper.WaitFor(15.Seconds());
            Assert.IsTrue(AppconnectSearchPage.IsUnpinned);
            Console.WriteLine("Pinned Successfully");
        }

        [Then(@"Close the search results")]
        public void ThenCloseTheSearchResults()
        {
            AppconnectSearchPage.SearchResutClose.Click();
        }

        [Then(@"Check pinned record matches")]
        public void ThenCheckPinnedRecordMatches()
        {
            WaitHelper.WaitFor(10.Seconds());
            Assert.AreEqual(" A Girl and Her P...", AppconnectSearchPage.GetMyFeedPinnedTitle);
            Console.WriteLine("Pinned Title Matched");
        }

        [Then(@"Unpin the searched record")]
        public void ThenUnpinTheSearchedRecord()
        {
            WaitHelper.WaitFor(10.Seconds());
            AppconnectSearchPage.UnpinnedRecord.Click();
            Assert.IsTrue(AppconnectSearchPage.IsPinned);
            Console.WriteLine("UnPinned Successfully");
        }

        [When(@"Click on ISBN")]
        public void WhenClickOnISBN()
        {
            WaitHelper.WaitFor(10.Seconds());
            AppconnectSearchPage.SelectISBN.Click();
            WaitHelper.WaitFor(10.Seconds());
        }

        [Then(@"Verify user is on mailing list page")]
        public void ThenVerifyUserIsOnMailingListPage()
        {
            WaitHelper.WaitFor(10.Seconds());
            Assert.IsTrue(MailingPage.CreateNewListButtonDisplayed);
        }

        [When(@"Click on the ISBN link in the search result")]
        public void WhenClickOnTheISBNLinkInTheSearchResult()
        {
            WaitHelper.WaitFor(15.Seconds());
            AppconnectSearchPage.ISBN_ViewBook.Click();
        }

        [Then(@"Mailing list should be displayed")]
        public void ThenMailingListShouldBeDisplayed()
        {
            WaitHelper.WaitFor(15.Seconds());
            Assert.IsTrue(MailingPage.CreateNewListButton.Visible);
            Console.WriteLine("Mailing Page is Loaded");
        }
    }
}
