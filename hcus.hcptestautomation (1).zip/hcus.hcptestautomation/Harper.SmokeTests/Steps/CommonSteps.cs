﻿using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.Exceptions;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using NUnit.Framework;
using System;
using System.Linq;
using HARP.AutomationFramework.WebElementWrappers;
using Harper.SmokeTests.PageObjects;
using TechTalk.SpecFlow;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;

namespace Harper.SmokeTests.Steps
{
    [Binding]
    public class CommonSteps : BaseSteps
    {
        [Given(@"I'm on the Home page")]
        [Given(@"I'm on the Appconnect Home page")]
        public void GivenImOnTheHomePage()
        {
            switch (AppSettings.CurrentSettings.ClientVersion)
            {
                case EnvVersion.Modern:
                    LogInModern();
                    break;
                case EnvVersion.Legacy:
                    LogInLegacy();
                    break;
                default:
                    LogInLegacy();
                    break;
            }

            if (!WaitHelper.WaitUntil(() => HomePage.IsOpened))
                throw new AutomationException(
                    "Home page is not on the screen.");
        }

        [Then(@"I should see '(.*)' text on Home Page")]
        public void ThenIShouldSeeTextOnHomePage(string message)
        {
            WaitHelper.WaitFor(5.Seconds());
            Assert.AreEqual(message, HomePage.HomePageFeed.Text);
        }


        private void LogInModern()
        {
            var url = AppSettings.CurrentSettings.Environments.First(env => env.Version == EnvVersion.Modern).Url;
            HomePage.GoToURL(url);
            WaitHelper.WaitFor(5.Seconds());
        }

        private void LogInLegacy()
        {
            var url = AppSettings.CurrentSettings.GetAuthUrl();
            HomePage.GoToURL(url);
        }

    }
}