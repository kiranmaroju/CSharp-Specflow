﻿using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using NUnit.Framework;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace Harper.SmokeTests.Steps
{
    [Binding]
    public class TravelSteps : BaseSteps
    {
        [Then(@"Select ISBN and Navigate to Book Details")]
        public void ThenSelectISBNAndNavigateToBookDetails()
        {
            TravelPage.ISBNSelect.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [Then(@"Navigate to Travel tab")]
        public void ThenNavigateToTravelTab()
        {
            TravelPage.Traveltab.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [Then(@"Search with Confirmation Number")]
        public void ThenSearchWithConfirmationNumber()
        {
            string confirmationNo = TravelPage.ConfirmationNumber.GetAttributeValue("innerHTML");
            TravelPage.ConfirmationNumberSearch.SendText(confirmationNo.Trim());
            WaitHelper.WaitFor(2.Seconds());
        }

        [Then(@"Verify Confirmation number is getting displayed")]
        public void ThenVerifyConfirmationNumberIsGettingDisplayed()
        {
            Assert.IsTrue(TravelPage.ConfirmationNoDisplayed);
        }

        [Then(@"Search with Date")]
        public void ThenSearchWithDate()
        {
            string DateExtract = TravelPage.Date.GetAttributeValue("innerHTML");
            string DateOnly = DateExtract.Remove(DateExtract.IndexOf(' '));
            TravelPage.DateSearch.SendText(DateOnly.Trim());
            WaitHelper.WaitFor(2.Seconds());
        }

        [Then(@"Verify Date is getting displayed")]
        public void ThenVerifyDateIsGettingDisplayed()
        {
            Assert.IsTrue(TravelPage.DateDisplayed);
        }

    }
}
