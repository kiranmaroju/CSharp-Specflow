﻿using AutoIt;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using Harper.SmokeTests.Models;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Harper.SmokeTests.Steps
{
    [Binding]
    public class ContactFeatureSteps : BaseSteps
    {

        string InitialCount;
        string FinalCount;

        [When(@"I am Create Contact page")]
        public void WhenIAmCreateContactPage()
        {
            MenuPage.Contacts.Click();
            MenuPage.CreateNewContact.Click();
        }

        [When(@"Enter all Mandatory Fields")]
        public void WhenEnterAllMandatoryFields(Table table)
        {
            var Params = table.CreateInstance<Details>();
            ContactPage.FillAllRequiredFields(Params);
        }

        [When(@"Enter all Fields")]
        public void WhenEnterAllFields(Table table)
        {
            var Params = table.CreateInstance<Details>();
            ContactPage.FillAllFields(Params);
        }

        [When(@"Save The Contact")]
        public void WhenSaveTheContact()
        {
            WaitHelper.WaitFor(13.Seconds());
            ContactPage.SaveContactButton.Click();
            ContactPage.WaitUntilLoadSpinnerDisappear();
            WaitHelper.WaitFor(10.Seconds());
        }

        [When(@"I am Contact Search page")]
        public void WhenIAmContactSearchPage()
        {
            WaitHelper.WaitFor(16.Seconds());
            MenuPage.Contacts.Click();
            WaitHelper.WaitFor(13.Seconds());
            MenuPage.SearchForContacts.Click();
        }

        [When(@"Search the contact Created")]
        public void WhenSearchTheContactCreated(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Email");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Search the contact Created muckrack")]
        public void WhenSearchTheContactCreatedMuckrack(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Email");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }


        [Then(@"Edit the contact Details")]
        public void ThenEditTheContactDetails(Table table)
        {
            SearchContact.EditContactButton.Click();
            WaitHelper.WaitFor(15.Seconds());
            var Params = table.CreateInstance<Details>();
            ContactPage.EditAllRequiredFields(Params);
        }

        [When(@"Search the Contact Edited")]
        public void WhenSearchTheContactEdited(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Mobile");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaEdited(Params);
            SearchContact.ContactSearchButton.Click();
        }

        [Then(@"Verify Contact is added to Group")]
        [Then(@"Search result is displayed")]
        public void ThenSearchResultIsDisplayed()
        {
            WaitHelper.WaitUntil(()=> SearchContact.IsOpened, 90.Seconds(), 90.Seconds());
            WaitHelper.WaitFor(20.Seconds());
            Assert.IsTrue(SearchContact.IsOpened);
            Console.WriteLine("Search Result Displayed");
        }

        [Then(@"Verify name is displayed")]
        public void ThenVerifyNameIsDisplayed()
        {
            WaitHelper.WaitFor(15.Seconds());
            Assert.AreEqual("Grey, Thomson", ContactPage.ContactName.Text);
        }

        [Then(@"Delete Contact from Group")]
        [When(@"Delete the Contact created")]
        public void WhenDeleteTheContactCreated()
        {
            SearchContact.DeleteContactButton.Click();
            WaitHelper.WaitFor(15.Seconds());
            SearchContact.DeleteContactOkButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [Then(@"Search result is not displayed")]
        public void ThenSearchResultIsNotDisplayed()
        {
            WaitHelper.WaitFor(15.Seconds());
            Assert.IsFalse(SearchContact.IsOpened);
            Console.WriteLine("Search Result not Displayed");
        }

        [When(@"I am Upload Contact page")]
        public void WhenIAmUploadContactPage()
        {
            MenuPage.Contacts.Click();
            MenuPage.UploadContact.Click();
        }

        [When(@"Upload Contact csv")]
        public void WhenUploadContact()
        {
            
            var rootPath = System.AppContext.BaseDirectory;
            Console.WriteLine(rootPath);
            var projectPath = rootPath.Substring(0, rootPath.IndexOf("\\bin"));
            Console.WriteLine(projectPath);
            var filePath = System.IO.Path.Combine(projectPath, "Files", "GreyCSV.csv");
            Console.WriteLine(filePath);
            WaitHelper.WaitFor(15.Seconds());
            ContactPage.UploadButtonCsv.Click();
            AutoItX.WinActivate("Open");
            Thread.Sleep(5000);
            AutoItX.Send(filePath);
            Thread.Sleep(3000);
            
            AutoItX.Send("{ENTER}");

            WaitHelper.WaitFor(20.Seconds());
            ContactPage.ConfirmUploadButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Upload Contact cision")]
        public void WhenUploadContactCision()
        {
            var rootPath = System.AppContext.BaseDirectory;
            Console.WriteLine(rootPath);
            var projectPath = rootPath.Substring(0, rootPath.IndexOf("\\bin"));
            Console.WriteLine(projectPath);
            var filePath = System.IO.Path.Combine(projectPath, "Files", "GreyCision.csv");
            Console.WriteLine(filePath);
            WaitHelper.WaitFor(15.Seconds());
            ContactPage.UploadButtonCision.Click();
            AutoItX.WinActivate("Open");
            Thread.Sleep(5000);
            AutoItX.Send(filePath);
            Thread.Sleep(3000);
            AutoItX.Send("{ENTER}");

            WaitHelper.WaitFor(20.Seconds());
            ContactPage.ConfirmUploadButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Upload Contact muckrack")]
        public void WhenUploadContactMuckrack()
        {
            var rootPath = System.AppContext.BaseDirectory;
            Console.WriteLine(rootPath);
            var projectPath = rootPath.Substring(0, rootPath.IndexOf("\\bin"));
            Console.WriteLine(projectPath);
            var filePath = System.IO.Path.Combine(projectPath, "Files", "GreyMuckrack.csv");
            Console.WriteLine(filePath);
            WaitHelper.WaitFor(15.Seconds());
            ContactPage.UploadButtonMuckrack.Click();
            AutoItX.WinActivate("Open");
            Thread.Sleep(5000);
            AutoItX.Send(filePath);
            Thread.Sleep(3000);
            AutoItX.Send("{ENTER}");

            WaitHelper.WaitFor(20.Seconds());
            ContactPage.ConfirmUploadButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"I am on Create New Group Page")]
        public void WhenIAmOnCreateNewGroupPage()
        {
            MenuPage.Contacts.Click();
            MenuPage.CreateNewGroup.Click();
        }

        [When(@"Enter New Group Details and click add contact")]
        public void WhenEnterNewGroupDetailsAndClickAddContact(Table table)
        {
            var Params = table.CreateInstance<Details>();
            ContactPage.FillGroupFields(Params);
            ContactPage.AddGroupContact.Click();

        }

        [When(@"Add Contact to Group and Save")]
        public void WhenAddContactToGroupAndSave()
        {
            ContactPage.AddingContact.Click();
            ContactPage.CloseAddPopup.Click();
            WaitHelper.WaitFor(25.Seconds());
            ContactPage.SaveGroup.Click();
        }

        [Then(@"Delete the Group")]
        public void ThenDeleteTheGroup()
        {
            ContactPage.DeleteGroup.Click();
            ContactPage.DeleteGroupOK.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Verify search results are displayed")]
        public void WhenVerifySearchResultsAreDisplayed()
        {
            WaitHelper.WaitFor(20.Seconds());
            Assert.IsTrue(ContactPage.AddingContactDisplayed);
            WaitHelper.WaitFor(22.Seconds());
        }


        [When(@"Search the contact Created with name")]
        
        public void WhenSearchTheContactCreatedWithName(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Name");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Search the contact Created with partial company name")]
        public void WhenSearchTheContactCreatedWithPartialCompanyName(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Company");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByPartialCompanyName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Search the contact Created with company name")]
        public void WhenSearchTheContactCreatedWithCompanyName(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Company");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByCompanyName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }


        [When(@"Search with MediaType")]
        public void WhenSearchWithMediaType()
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("mediaTypes");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.SendText(Keys.Enter);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(30.Seconds());
        }


        [Then(@"Delete the contact from the Group")]
        public void ThenDeleteTheContactFromTheGroup()
        {
            WaitHelper.WaitFor(15.Seconds());
            ContactPage.SelectContact.Click();
            ContactPage.RemoveContact.Click();
            ContactPage.DeleteGroupOK.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Expand Search")]
        public void WhenExpandSearch()
        {
            ContactPage.ExpandCollaspeContact.Click();
            WaitHelper.WaitFor(12.Seconds());
        }

        [When(@"Verify Duplicate Record message is displayed")]
        public void WhenVerifyDuplicateRecordMessageIsDisplayed()
        {
            WaitHelper.WaitFor(12.Seconds());
            Assert.IsTrue(ContactPage.UploadDuplicateMessageDisplayed);
            WaitHelper.WaitFor(12.Seconds());
        }

        [Then(@"Overwrite and confirm")]
        public void ThenOverwriteAndConfirm()
        {
            WaitHelper.WaitFor(12.Seconds());
            ContactPage.DuplicateRecordMessage.Click();
            WaitHelper.WaitFor(12.Seconds());
            ContactPage.OverwriteDuplicate.Click();
            WaitHelper.WaitFor(12.Seconds());
            ContactPage.ConfirmUploadButton.Click();
            WaitHelper.WaitFor(10.Seconds());
        }

        [Then(@"Get Inital No of contacts")]
        public void ThenGetInitalNoOfContacts()
        {
            WaitHelper.WaitFor(12.Seconds());
            InitialCount = ContactPage.ReturnCount();
            WaitHelper.WaitFor(12.Seconds());
        }

        [Then(@"Select the Group icon and select group from popup")]
        public void ThenSelectTheGroupIconAndSelectGroupFromPopup()
        {
            WaitHelper.WaitFor(12.Seconds());
            ContactPage.SelectGroup.Click();
            WaitHelper.WaitFor(12.Seconds());
        }

        [Then(@"Get Final No of contacts")]
        public void ThenGetFinalNoOfContacts()
        {
            WaitHelper.WaitFor(12.Seconds());
            FinalCount = ContactPage.ReturnCount();
            WaitHelper.WaitFor(12.Seconds());
        }

        [Then(@"Verify the no of contacts added are same")]
        public void ThenVerifyTheNoOfContactsAddedAreSame()
        {
            WaitHelper.WaitFor(12.Seconds());
            Assert.AreEqual(InitialCount, FinalCount);
            WaitHelper.WaitFor(12.Seconds());
        }

        [Then(@"Search with Media Type")]
        public void ThenSearchWithMediaType()
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("mediaTypes");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.SendText(Keys.Enter);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(20.Seconds());
        }

        [Then(@"Search the Market")]
        public void ThenSearchTheMarket()
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("markets");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.SendText(Keys.Enter);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(16.Seconds());
        }

        [Then(@"Search the Languages")]
        public void ThenSearchTheLanguages()
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("languages");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.SendText(Keys.Enter);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(30.Seconds());
        }

        [Then(@"Search the Categories")]
        public void ThenSearchTheCategories()
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("topics");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.SendText(Keys.Enter);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(90.Seconds());
        }

        [Then(@"Search based on Created By '(.*)'")]
        public void ThenSearchBasedOnCreatedBy(string createdBy)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("CreatedBy");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(createdBy);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(30.Seconds());
        }

        [Then(@"Search based on Updated By '(.*)'")]
        public void ThenSearchBasedOnUpdatedBy(string updatedBy)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("UpdatedBy");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(updatedBy);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(30.Seconds());
        }

        [Then(@"Search the Name")]
        public void ThenSearchTheName(Table table)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("Name");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(12.Seconds());
        }

        [Then(@"Search the Company")]
        public void ThenSearchTheCompany(Table table)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("Company");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByCompanyName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [Then(@"Search the Show Name")]
        public void ThenSearchTheShowName(Table table)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("ShowName");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByShowName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [Then(@"Search the Job Title")]
        public void ThenSearchTheJobTitle(Table table)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("JobTitle");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByJobTitle(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [Then(@"Search the Mobile")]
        public void ThenSearchTheMobile(Table table)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("Mobile");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByMobile(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(15.Seconds());
        }

        [Then(@"Search the Office")]
        public void ThenSearchTheOffice(Table table)
        {
            ContactPage.SearchExpandCollaspeContact.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("Office");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByOffice(Params);
            SearchContact.ContactSearchButton.Click();
           WaitHelper.WaitFor(15.Seconds());
        }


    }
}
