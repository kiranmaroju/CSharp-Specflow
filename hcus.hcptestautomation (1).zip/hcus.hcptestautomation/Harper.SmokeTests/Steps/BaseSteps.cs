﻿using HARP.AutomationFramework;
using Harper.SmokeTests.PageObjects;

namespace Harper.SmokeTests.Steps
{
    public class BaseSteps : GlobalSteps
    {
        protected HomePage HomePage { get; } = new HomePage();
        protected AppconnectSearchPage AppconnectSearchPage { get; } = new AppconnectSearchPage();
        protected MenuPage MenuPage { get; } = new MenuPage();
        protected ContactPage ContactPage { get; } = new ContactPage();
        protected SearchContact SearchContact { get; } = new SearchContact();
        protected EventPage EventPage { get; } = new EventPage();
        protected MailingPage MailingPage { get; } = new MailingPage();

        protected TravelPage TravelPage { get; } = new TravelPage();
    }
}
