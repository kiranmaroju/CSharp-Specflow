﻿using HARP.AutomationFramework.Enums;
using HARP.AutomationFramework.Utilities;
using HARP.AutomationFramework.WebElementWrappers.CommonHelpers;
using HARP.AutomationFramework.WebElementWrappers.WrapperTypes;
using Harper.SmokeTests.Models;
using Harper.SmokeTests.Steps;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using AutoIt;
using System.Threading;
using OpenQA.Selenium;

namespace Harper.SmokeTests
{
    [Binding]
    public class MailingFeatureSteps : BaseSteps
    {
        bool initialState;
        bool finalState;
        string t;
        string i;
        string a;
        string s;

        [When(@"I am on Mailing page")]
        public void WhenIAmOnMailingPage()
        {
            MailingPage.MailingLinkButton.Click();
            WaitHelper.WaitFor(5.Seconds());
            /*MailingPage.CreateNewListButton.Click();
            WaitHelper.WaitFor(3.Seconds());*/
        }

        [When(@"Create an mailing list")]
        public void WhenCreateAnMailingList(Table table)
        {
            t = getTitle();
            i = getISBN();
            a = getAuthor();
            s = getSeason();
            Console.WriteLine(t, i, a, s);
            WaitHelper.WaitFor(3.Seconds());
            MailingPage.MailingButton.Click();
            MailingPage.CreateNewListButton.Click();
            WaitHelper.WaitFor(3.Seconds());
            var Params = table.CreateInstance<Details>();
            MailingPage.FillListFields(Params);
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"Navigate to List search for contact")]
        public void WhenNavigateToListSearchForContact()
        {
            WaitHelper.WaitFor(4.Seconds());
            MailingPage.AddToListButton.Click();
            MailingPage.ListSearchContactButton.Click();
            WaitHelper.WaitFor(4.Seconds());
            //MailingPage.ShowHideSearch.Click();
            WaitHelper.WaitFor(4.Seconds());
        }

        [When(@"Navigate to List Create New Contact")]
        public void WhenNavigateToListCreateNewContact()
        {
            MailingPage.AddToListButton.Click();
            MailingPage.ListCreateContactButton.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"I am on Mailing Search Page")]
        public void WhenIAmOnMailingSearchPage()
        {
            WaitHelper.WaitFor(3.Seconds());
            MenuPage.Mailings.Click();
            MenuPage.SearchForMailing.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"Search for List created")]
        public void WhenSearchForListCreated(Table table)
        {
            var Params = table.CreateInstance<Details>();
            MailingPage.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Delete the list created")]
        public void WhenDeleteTheListCreated()
        {
            WaitHelper.WaitFor(15.Seconds());
            MailingPage.DeleteListButton.Click();
            WaitHelper.WaitFor(5.Seconds());
            MailingPage.DeleteListOkButton.Click();
            WaitHelper.WaitFor(10.Seconds());
        }

        [Then(@"Verify Delete button is not displayed")]
        public void ThenVerifyDeleteButonIsNotDisplayed()
        {
            WaitHelper.WaitFor(3.Seconds());
            Assert.IsFalse(MailingPage.DeleteOption);
            WaitHelper.WaitFor(2.Seconds());
        }

        [Then(@"Navigate to HomePage")]
        public void ThenNavigateToHomePage()
        {
            HomePage.Logo.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [When(@"Navigate to List Upload Contact")]
        public void WhenNavigateToListUploadContact()
        {
            MailingPage.AddToListButton.Click();
            MailingPage.ListUploadContactButton.Click();
            WaitHelper.WaitFor(3.Seconds());
        }


        [Then(@"Add Contact to mailing list and Save")]
        public void ThenAddContactToMailingListAndSave()
        {
            MailingPage.ContactAddingListSelectButton.Click();
            MailingPage.AddContactListButton.Click();
            WaitHelper.WaitFor(2.Seconds());
        }

        [Then(@"Verify Mailing List is copied")]
        [Then(@"Verify mailing list is displayed")]
        public void ThenVerifyMailingListIsDisplayed()
        {
            WaitHelper.WaitFor(15.Seconds());
            Assert.IsTrue(SearchContact.IsOpened);
            Console.WriteLine("Search Result Displayed");
            WaitHelper.WaitFor(5.Seconds());
        }

        [Then(@"Verify mailing list is not displayed")]
        public void ThenVerifyMailingListIsNotDisplayed()
        {
            Assert.IsFalse(SearchContact.IsOpened);
            Console.WriteLine("Search Result not Displayed");
        }

        [When(@"Export Mailing report")]
        public void WhenExportMailingReport()
        {
            WaitHelper.WaitFor(15.Seconds());
            Assert.IsTrue(MailingPage.ExportEnabled);
            MailingPage.ExportButton.Click();
            MailingPage.SaveListButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [Then(@"Copy Mailing List")]
        public void ThenCopyMailingList(Table table)
        {
            var Params = table.CreateInstance<Details>();
            MailingPage.CopyNewMailingList(Params);
            WaitHelper.WaitFor(15.Seconds());
        }

        [When(@"Enter (.*) for Contact")]
        public void WhenEnterForContact(string quantity)
        {
            MailingPage.Quantity.Click();
            MailingPage.Quantity.CleanField();
            MailingPage.Quantity.SendText(quantity);
            MailingPage.Send.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"Enter (.*) then cancel")]
        public void WhenEnterSpecialInstructionsThenCancel(string ins)
        {
            MailingPage.Warehouse.Click();
            WaitHelper.WaitFor(3.Seconds());
            MailingPage.WarehouseContinue.Click();
            WaitHelper.WaitFor(3.Seconds());
            MailingPage.WarehouseSpecialInstructions.CleanField();
            MailingPage.WarehouseSpecialInstructions.SendText(ins);
            MailingPage.SpecialInstructionsSave.Click();
            WaitHelper.WaitFor(4.Seconds());
            MailingPage.Cancel.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"Enter (.*) then confirm")]
        public void WhenEnterClickOnConfirmButtonThenConfirm(string ins)
        {
            MailingPage.Warehouse.Click();
            WaitHelper.WaitFor(3.Seconds());
            /*MailingPage.WarehouseContinue.Click();
            WaitHelper.WaitFor(3.Seconds());*/
            MailingPage.WarehouseSpecialInstructions.CleanField();
            MailingPage.WarehouseSpecialInstructions.SendText(ins);
            MailingPage.SpecialInstructionsSave.Click();
            WaitHelper.WaitFor(4.Seconds());
            MailingPage.Confirm.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [When(@"Enter (.*) then confirm and OK")]
        public void WhenEnterClickOnConfirmButtonThenConfirmAndOK(string ins)
        {
            MailingPage.Warehouse.Click();
            WaitHelper.WaitFor(8.Seconds());
            MailingPage.WarehouseSpecialInstructions.CleanField();
            MailingPage.WarehouseSpecialInstructions.SendText(ins);
            MailingPage.SpecialInstructionsSave.Click();
            WaitHelper.WaitFor(4.Seconds());
            MailingPage.Confirm.Click();
            WaitHelper.WaitFor(12.Seconds());
            MailingPage.ConfirmOK.Click();
            WaitHelper.WaitFor(12.Seconds());
        }


        [When(@"Perform Collaspe Action")]
        [Then(@"Perform Expand Action")]
        public void WhenPerformCollaspeAction()
        {
            WaitHelper.WaitFor(5.Seconds());
            MailingPage.ExpandCollaspe.Click();
            WaitHelper.WaitFor(2.Seconds());
        }

        [Then(@"Verify Details are collasped")]
        public void ThenVerifyDetailsAreCollasped()
        {
            Assert.IsFalse(MailingPage.EbookISBNDisplayed);
        }

        [Then(@"Verify Details are expanded")]
        public void ThenVerifyDetailsAreExpanded()
        {
            Assert.IsTrue(MailingPage.EbookISBNDisplayed);
        }

        [When(@"Click on Settings and Set as Default")]
        public void WhenClickOnSettingsAndSetAsDefault()
        {
            WaitHelper.WaitFor(10.Seconds());
            MailingPage.Settings.Click();
            initialState = MailingPage.CategoriesState;
            MailingPage.SetAsDefault.Click();
        }

        [When(@"Save the updated Setting")]
        public void WhenSaveTheUpdatedSetting()
        {
            finalState = MailingPage.CategoriesState;
            MailingPage.Save.Click();
        }

        [When(@"Click on Settings and mark fields as checked")]
        public void WhenClickOnSettingsAndMarkFieldsAsChecked()
        {
            MailingPage.Settings.Click();
            MailingPage.CategoriesCheckboxCheck.Click();
        }

        [Then(@"Verify Settings are updated")]
        public void ThenVerifySettingsAreUpdated()
        {
            Assert.AreNotEqual(initialState, finalState);
        }

        [When(@"Navigate to Mailing page")]
        public void WhenNavigateToMailingPage()
        {
            MailingPage.MailingLinkButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [Then(@"Select the contact")]
        public void ThenSelectTheContact()
        {
            WaitHelper.WaitFor(5.Seconds());
            ContactPage.SelectContact.Click();
        }

        [Then(@"Click on Send Button and Select Email Blast")]
        public void ThenClickOnSendButtonAndSelectEmailBlast()
        {
            MailingPage.MailingSend.Click();
            MailingPage.MailingEmailBlast.Click();
            WaitHelper.WaitFor(3.Seconds());
        }

        [Then(@"Enter Details related to Email Subject '(.*)' , Body '(.*)'")]
        public void ThenEnterDetailsRelatedToEmailSubjectBody(string sub, string body)
        {
            MailingPage.MailingEmailSubject.SendText(sub);
            MailingPage.MailingEmailBody.SendText(body);
            WaitHelper.WaitFor(3.Seconds());
        }

        [Then(@"Upload the file and Send")]
        public void ThenUploadTheFileAndSend()
        {
            var rootPath = System.AppContext.BaseDirectory;
            Console.WriteLine(rootPath);
            var projectPath = rootPath.Substring(0, rootPath.IndexOf("\\bin"));
            Console.WriteLine(projectPath);
            var filePath = System.IO.Path.Combine(projectPath, "Files", "GreyCSV.csv");
            Console.WriteLine(filePath);

            MailingPage.MailingAttach.Click();
            AutoItX.WinActivate("Open");
            Thread.Sleep(5000);
            AutoItX.Send(filePath);
            Thread.Sleep(3000);
            AutoItX.Send("{ENTER}");

            WaitHelper.WaitFor(10.Seconds());
            MailingPage.MailingSendEmail.Click();
        }

        public string getTitle()
        {
            return MailingPage.ReturnTitle();
        }

        public string getISBN()
        {
            return MailingPage.GetMailingData(MailingPage.ISBN);
        }

        public string getAuthor()
        {
            return MailingPage.GetMailingData(MailingPage.AuthorName);
        }

        public string getSeason()
        {
            return MailingPage.GetMailingData(MailingPage.SeasonMonth);
        }

        [Then(@"Search for list created based on Title")]
        public void ThenSearchForListCreatedBasedOnTitle()
        {
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("bookTitle");
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(t);
            Console.WriteLine(getTitle());
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(35.Seconds());
        }

        [Then(@"Search for list created based on ISBN")]
        public void ThenSearchForListCreatedBasedOnISBN()
        {
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("isbn");
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(i);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(35.Seconds());
        }

        [Then(@"Search for list created based on AuthorName")]
        public void ThenSearchForListCreatedBasedOnAuthorName()
        {
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("authorName");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(a);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(35.Seconds());
        }

        [Then(@"Search for list created based on Created By '(.*)'")]
        public void ThenSearchForListCreatedBasedOnCreatedBy(string createdby)
        {
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("CreatedBy");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(createdby);
            WaitHelper.WaitFor(2.Seconds());
            SearchContact.SearchContactBar.SendText(Keys.Enter);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(60.Seconds());
        }

        [Then(@"Search for list created based on Date Created")]
        public void ThenSearchForListCreatedBasedOnDateCreated()
        {
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("dateCreated");
            WaitHelper.WaitFor(2.Seconds());
            SearchContact.DateSearch.Click();
            SearchContact.DateSearch.CleanField();
            SearchContact.DateSearch.SendText(System.DateTime.Now.ToString("MM/dd/yyyy"));
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(60.Seconds());
        }

        [Then(@"Search for list created based on SeasonMonth")]
        public void ThenSearchForListCreatedBasedOnSeasonMonth()
        {
            WaitHelper.WaitFor(5.Seconds());
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("season");
            SearchContact.SearchContactBar.Click();
            SearchContact.SearchContactBar.CleanField();
            SearchContact.SearchContactBar.SendText(MailingPage.GetMailingData(MailingPage.SeasonMonth));
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(60.Seconds());
        }

        [Then(@"Search for list created based on ContactName")]
        public void ThenSearchForListCreatedBasedOnContactName(Table table)
        {
            SearchContact.SearchExpandCollaspe.Click();
            SearchContact.ContactSelectFeild.SelectValueByValue("contactName");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteriaByName(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(60.Seconds());
        }

        [Then(@"Click on Add Titles")]
        public void ThenClickOnAddTitles()
        {
            WaitHelper.WaitFor(2.Seconds());
            MailingPage.AddTitles.Click();
            WaitHelper.WaitFor(5.Seconds());
        }

        [Then(@"Enter (.*) search and add isbn")]
        public void ThenEnterSearchAndAddIsbn(string isbn)
        {
            WaitHelper.WaitFor(6.Seconds());
            MailingPage.TitlesSearch.SendText(isbn);
            MailingPage.TitlesSearch.SendText(Keys.Enter);
            WaitHelper.WaitFor(4.Seconds());
            MailingPage.TitlesAddISBN.Click();
            WaitHelper.WaitFor(4.Seconds());
            MailingPage.TitlesClose.Click();
            WaitHelper.WaitFor(4.Seconds());
        }

        [When(@"Create a new Public contact from the list")]
        public void WhenCreateANewPublicContactFromTheList(Table table)
        {
            MailingPage.AddToListButton.Click();
            MailingPage.CreateNewContact.Click();
            WaitHelper.WaitFor(2.Seconds());
            var Params = table.CreateInstance<Details>();
            ContactPage.PublicContactWithEmail(Params);
            WaitHelper.WaitFor(3.Seconds());
            Assert.IsTrue(MailingPage.Viewcontact.Visible);
            WaitHelper.WaitFor(3.Seconds());

        }

        [When(@"Create a new List Specific contact from the list")]
        public void WhenCreateANewListSpecificContactFromTheList(Table table)
        {
            MailingPage.AddToListButton.Click();
            MailingPage.CreateNewContact.Click();
            WaitHelper.WaitFor(2.Seconds());
            var Params = table.CreateInstance<Details>();
            ContactPage.ListSpecificContactWithEmail(Params);
            WaitHelper.WaitFor(3.Seconds());
            Assert.IsTrue(MailingPage.Viewcontact.Visible);
            WaitHelper.WaitFor(3.Seconds());
        }

        [Then(@"New Mailing list should be created")]
        public void ThenNewMailingListShouldBeCreated()
        {
            WaitHelper.WaitFor(6.Seconds());
            MailingPage.MailingListTab.Click();
            WaitHelper.WaitElement(MailingPage.MailingListName);
            Assert.IsTrue(MailingPage.MailingListName.Visible);
            MailingPage.MailingListName.Click();

        }

        [When(@"Perform valid Isbn search")]
        public void WhenPerformValidIsbnSearch(Table table)
        {
            var Params = table.CreateInstance<Details>();
            AppconnectSearchPage.SearchByISBN(Params);
        }

        [When(@"Click on the Create New List")]
        public void WhenClickOnTheCreateNewList()
        {
            WaitHelper.WaitFor(2.Seconds());
            MailingPage.CreateNewListButton.Click();

        }

        [When(@"Search the contact by the Email")]
        public void WhenSearchTheContactByEmail(Table table)
        {
            SearchContact.ContactSelectFeild.SelectValueByValue("Email");
            var Params = table.CreateInstance<Details>();
            SearchContact.EnterSearchCriteria(Params);
            SearchContact.ContactSearchButton.Click();
            WaitHelper.WaitFor(5.Seconds());
        }



    }
}
